function notifications() {
  if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
    var notification = new Notification("Tính năng mới" , {
      icon: "icon.png",
      body: "Tự động nhận biết đơn vị tiền tệ dựa trên trang web đang sử dụng. Click vào đây để đến trang hỗ trợ và gửi trang web bạn hay dùng. Cảm ơn bạn Nhật Tuấn Trần đã gợi ý tính năng này.",
    });
    // xử lý sự kiện khi click vào thông báo
    notification.onclick = function () {
        // url của kipalog để update status của notification và redirect tới trang của event(post, user page ...)
        window.open("https://chrome.google.com/webstore/detail/em-%C6%A1i-%C4%91%E1%BB%95i-ti%E1%BB%81n/fccdobmaecjklemcgjjkgbingioiapch/support");
    };
  }
}
notifications();